<?
header("Content-Type: text/html;charset=UTF-8");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<title>cloning</title>
		<link rel="stylesheet" href="cloning.css">
	</head>
	<body>
		<div id='clone1' class='container'>
			<div class="cloning-area">
				<div class="b-blinds__item myDiv hidden"><img class="myDivImg b-blinds__image" ></div>
		
			</div>
			<img class='images' src='http://viewswallpaper.com/wp-content/uploads/2014/07/Kim-Scott-Pilgrim-Comic-Wallpaper-1024x640.png'>
			<img class='images' src='http://viewswallpaper.com/wp-content/uploads/2014/07/Batman-Art-HD-Wallpaper-1024x640.jpg'>
			<img class='images' src='http://viewswallpaper.com/wp-content/uploads/2014/07/Young-Art-Wallpaper-1024x640.jpg'>
			<img class='images' src='http://viewswallpaper.com/wp-content/uploads/2014/07/Creative-Design-Wallpaper-1024x640.jpg'>
			<img class='images' src='http://viewswallpaper.com/wp-content/uploads/2014/06/Bada-Wallpapers.jpg'>
			
		</div>
	<script src="https://code.jquery.com/jquery-2.1.1.js"></script>
	<script src="clone.js"></script>
	<script>
		var c1	=	new b_blinds_gallery('#clone1');
	</script>
	</body>
</html>